import express from 'express'
import cors from 'cors'
import 'dotenv/config'

import dns from 'dns'
import connectDB from './config/mongodb.js'
import connectCloudinary from './config/cloudinary.js'
import adminRouter from './routes/adminRoute.js'
import doctorRouter from './routes/doctorroute.js'
import userRouter from './routes/userRoute.js'

// app config
const app = express()
const port = process.env.PORT || 4000

dns.setServers(['8.8.8.8', '1.1.1.1'])

connectDB()
connectCloudinary()


//middleware
app.use(express.json())
app.use(cors())


// api endpoint
app.use('/api/admin',adminRouter)
// localhost:4000/api/admin/app-doctor
app.use('/api/doctor',doctorRouter)
app.use('/api/user',userRouter)

app.get('/',(req,res)=>{
    res.send('API WORKING')
})

app.listen(port, ()=> console.log("Server Started",port))